"""Code for training loop of model"""
from typing import Dict,List,Tuple
import torchmetrics
from tqdm.auto import tqdm
from WithU.training import engine
import torch.nn as nn
import torch
from torch.utils.tensorboard.writer import SummaryWriter
device = 'cuda' if torch.cuda.is_available() else "cpu" # or 'cpu'
import itertools
def accuracy(y_pred,target):
  train_acc = torch.sum(y_pred == target)
  final_train_acc = train_acc/len(y_pred)
  return final_train_acc

def train(model:torch.nn.Module,
          optimizer: torch.optim.Adam,
          train_dataset: torch.utils.data.Dataset,
          test_dataset: torch.utils.data.Dataset,
          loss_fn: torch.nn.Module,
          accuracy_fn: torchmetrics.Accuracy,
          f1:torchmetrics.classification.F1Score,
          epochs:int,
          writer: torch.utils.tensorboard.writer.SummaryWriter,
          data_pipeline,
          device=device,
          strategy:str = "one-by-one",
          batch_size:int=32) -> Dict[str,List]:
  """Train function for pytorch model
  Function which tests a pytorch model and evaluates it based on loss, accuracy, and F1.
  Saves results to summary writer

  Args:
    model (torch.nn.Module): model to train
    optimizer (torch.optim.Adam): optimizer to use
    train_dataset (torch.utils.data.Dataset): Dataset class used to create dataloaders from for the training
    test_dataset (torch.utils.data.Dataset): test dataset used to create dataloaders from
    loss_fn (torch.nn.Module): loss function to use
    accuracy_fn (torchmetrics.Accuracy): Torchmetrics accuracy function to use
    f1 (torchmetrics.classification.F1Score): F1 score in torchmetrics library
    device: device to train on
    batch_size (int): batch size to train with
    epochs (int): number of epochs to train for
    writer (torch.utils.tensorboard.writer.SummaryWriter): writer instance to use
    strategy (str): "one-by-one" or "all" -> how to load and predict on each video. if "one-by-one", each video is passed through the data pipeline and predictions are made one video at a time and the final predictions stacked into a tensor
    if "all", then the whole batch is predicted on at once.
    data_pipeline: data pipeline to process each video for before putting the video through the model
  Returns:
    results dictionary with key metrics:
    e.g: {"train_loss":[...],
          "train_acc":[...],
          "train_f1":[...],
          "test_loss":[...]}
  """
  if strategy == "one-by-one" and data_pipeline == None:
    print(f"[WARNING] Training strategy is set to one-by-one but there is no data pipeline. Change training strategy to all or provide a data pipeline")
  #set up dictionary to store key values
  results = {"train_loss":[],"train_acc":[],"train_f1":[],"test_loss":[],"test_acc":[],"test_f1":[]}
  #create train and test dataloaders
  train_dataloader, test_dataloader = engine.create_dataloaders(train_dataset,test_dataset,batch_size)

  for epoch in tqdm(range(epochs)):
    train_loss,train_acc,train_f1 = engine.train_step(model=model,optimizer=optimizer,dataloader=train_dataloader,loss_fn=loss_fn,accuracy_fn=accuracy_fn,f1=f1,data_pipeline=data_pipeline,device=device,strategy=strategy)
    test_loss,test_acc,test_f1 = engine.test_step(model=model,optimizer=optimizer,dataloader=test_dataloader,loss_fn=loss_fn,accuracy_fn=accuracy_fn,f1=f1,device=device,strategy=strategy,data_pipeline=data_pipeline)

    #Add key metrics to results dictionary
    results["train_loss"].append(train_loss)
    results["train_acc"].append(train_acc)
    results["train_f1"].append(train_f1)
    results["test_loss"].append(test_loss)
    results["test_acc"].append(test_acc)
    results["test_f1"].append(test_f1)

    print(f"Epoch {epoch}: Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.4f} | Test Loss: {test_loss:.4f} | Test Acc: {test_acc:.4f}")
    #log scalars
    writer.add_scalars(main_tag="Loss",
                      tag_scalar_dict={"train_loss":train_loss,"test_loss":test_loss},
                      global_step=epoch)

    writer.add_scalars(main_tag="Accuracy",
                      tag_scalar_dict={"train_acc":train_acc,
                                    "test_acc":test_acc},
                      global_step=epoch)
    writer.add_scalars(main_tag="F1",
                      tag_scalar_dict={"train_f1":train_f1,
                                    "test_f1":test_f1},
                      global_step=epoch)
    # writer.add_graph(model=model,
    #                  input_to_model=torch.randn(1,32,3,224,224).to(device),
    #                  strict=False)
  writer.close()
  return results




#TODO => apply on all videos!! loop through batch and then change
