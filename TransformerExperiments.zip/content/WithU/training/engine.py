"""
Contains PyTorch functions for one step of training, testing, and an entire training loop
"""

import torch
from torch.utils.data import DataLoader
device = 'cuda' if torch.cuda.is_available() else "cpu" # or 'cpu'
import torch.nn as nn
import torchmetrics
from typing import List,Tuple,Dict
import tqdm
import itertools
def train_step(model:torch.nn.Module,
          optimizer: torch.optim.Adam,
          dataloader: torch.utils.data.DataLoader,
          loss_fn: torch.nn.Module,
          accuracy_fn: torchmetrics.Accuracy,
          f1:torchmetrics.classification.F1Score,
          data_pipeline,
          strategy:str = "one-by-one",
          device=device):
  """One training step for pytorch model
  Function which trains a pytorch model and evaluates it based on loss, accuracy, and F1.

  Args:
    model (torch.nn.Module): model to train
    optimizer (torch.optim.Adam): optimizer to use
    loss_fn (torch.nn.Module): loss function to use
    accuracy_fn (torchmetrics.Accuracy): Torchmetrics accuracy function to use
    f1 (torchmetrics.classification.F1Score): F1 score in torchmetrics library
    device: device to train on,
    data_pipeline: data pipeline to process each video for before putting the video through the model
    strategy (str): "one-by-one" or "all" -> how to load and predict on each video. if "one-by-one", each video is passed through the data pipeline and predictions are made one video at a time and the final predictions stacked into a tensor
    if "all", then the whole batch is predicted on at once.

  """
  #set to train mode and initialize key metrics
  model.train()
  train_loss,train_acc,train_f1 = 0,0,0

  for batch, (videos,target) in enumerate(dataloader):
    target = target.to(device)
    if strategy == "one-by-one":
      preds = []
      #process all videos
      for video in videos:
        processed_video = data_pipeline(list(video), return_tensors="pt",do_rescale=False)["pixel_values"]
        output = model(processed_video.to(device))
        predicted = output.logits
        if len(preds) == 0:
          preds = predicted
        else:
          preds = torch.vstack((preds,predicted))
    else:
      preds = model(videos.to(device))
    pred_probabilities = nn.functional.softmax(preds,dim=1)
    pred_label = pred_probabilities.argmax(dim=1)
    # print(f"Predicted label: {pred_label}. Shape of predicted probabilities: {pred_label.shape}")
    # print(f"Shape of Predicted probabilities: {pred_probabilities.shape}")
    # print(f"Targets: {target}")
    #calculate loss
    # print(f"Training predictions: {preds}")
    loss = loss_fn(preds,target)

    train_loss += loss
    train_acc += accuracy_fn(pred_label,target)
    train_f1 += f1(pred_label,target)

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

  #adjust train, test, and f1 accuracies
  len_dataloader = 8
  # train_loss /= len_dataloader
  # train_acc /= len_dataloader
  # train_f1 /= len_dataloader

  # print(f"Train Loss: {train_loss:.5f} | Train acc: {(train_acc*100):.4f} | Train F1: {train_f1:.4f}")
  return train_loss,train_acc,train_f1

def test_step(model:torch.nn.Module,
          optimizer: torch.optim.Adam,
          dataloader: torch.utils.data.DataLoader,
          loss_fn: torch.nn.Module,
          accuracy_fn: torchmetrics.Accuracy,
          f1:torchmetrics.classification.F1Score,
          data_pipeline,
          strategy:str = "one-by-one",
          device=device,
          batch_size:int=32):
  """One training step for pytorch model
  Function which tests a pytorch model and evaluates it based on loss, accuracy, and F1.

  Args:
    model (torch.nn.Module): model to train
    optimizer (torch.optim.Adam): optimizer to use
    loss_fn (torch.nn.Module): loss function to use
    accuracy_fn (torchmetrics.Accuracy): Torchmetrics accuracy function to use
    f1 (torchmetrics.classification.F1Score): F1 score in torchmetrics library
    device: device to train on
    data_pipeline: data pipeline to process each video for before putting the video through the model
    strategy (str): "one-by-one" or "all". If "one-by-one,

  """
  #set to train mode and initialize key metrics
  model.eval()
  test_loss,test_acc,test_f1 = 0,0,0

  with torch.inference_mode():
    for batch, (videos,target) in enumerate(dataloader):
      target = target.to(device)
      if strategy == "one-by-one":
        preds = []
        #process all videos
        # print(f"Batch number: {batch}")
        for video in videos:
            # assert prev_video != video, "The previous video is the same as the current video!"
            processed_video = data_pipeline(list(video), return_tensors="pt",do_rescale=False)["pixel_values"]
            output = model(processed_video.to(device))
            predicted = output.logits
            if len(preds) == 0:
              preds = predicted
            else:

              preds = torch.vstack((preds,predicted))
            # prev_video = video
      #calculate predicted label
      else:
        preds = model(videos.to(device))
      prediction_probabilities = nn.functional.softmax(preds,dim=1)
      pred_labels = prediction_probabilities.argmax(dim=1)

      # print(f"Test prediction shape: {preds.shape}")
      loss = loss_fn(preds,target)

      test_loss += loss
      # print(f"In Test batch {batch}, predictions are: {preds} target is {target}")
      test_acc += accuracy_fn(pred_labels,target)
      test_f1 += f1(pred_labels,target)


    #adjust train, test, and f1 accuracies

    len_dataloader = len(dataloader)
    # print(f"Length of dataloader: {len(dataloader)}")
    # test_loss /= 8
    # test_acc /= 8
    # test_f1 /= 8

    # print(f"Train Loss: {test_loss:.5f} | Train acc: {(test_acc*100):.4f} | Train F1: {test_f1:.4f}")
    return test_loss,test_acc,test_f1

def create_dataloaders(train_dataset:torch.utils.data.Dataset,
                                      test_dataset: torch.utils.data.Dataset,
                                      batch_size: int=8) -> Tuple[torch.utils.data.DataLoader,torch.utils.data.DataLoader]:
  """Creates train and test dataloaders from datasets
  Args:
    train_dataset (torch.utils.data.Dataset): subclass of Dataset class for training
    test_dataset (torch.utils.data.Dataset): subclass of Dataset class for testing
    batch_size (int): batch size
  Returns:
    Tuple of (train_dataloader,test_dataloader)
  """
  train_dataloader = DataLoader(train_dataset,batch_size=batch_size,num_workers=1)
  test_dataloader = DataLoader(test_dataset,batch_size=batch_size,num_workers=1)
  return train_dataloader,test_dataloader

