"""
Utility functions for downloading data and others

"""
from pathlib import Path
import requests
import os
import zipfile
def load_data(data_folder:str,
	     file_name:str,
	     source: str,
             remove_source: bool = True):
  """Download dataset from remote repository and unzips it
  Args:
    data_folder (str): name of data folder as a string (e.g: "data")
    dataset_folder (str): name of dataset folder as zip file (e.g: "With U Bisei Dataset.zip")
    source (str): GitHub raw link
    remove_source (bool): whether or not to remove the source zip folder

  Sample usage:
load_data("data","With U Bisei Lego Dataset.zip","https://github.com/Andrewzekid/WithU/raw/main/With%20U%20Bisei%20Lego%20Dataset.zip")
  """
  data_folder = "data" #where the folder containing the dataset is located
  dataset_folder = file_name.split(".")[0]

  data_path = Path(data_folder)
  dataset_path = data_path / dataset_folder

  if data_path.is_dir():
    print(f"[INFO] {data_path} folder found, skipping download...")
  else:
    print(f"[INFO] {data_path} folder not found, now downloading...")
    #create directory
    dataset_path.mkdir(parents=True,exist_ok=True)
    with open(data_path / "With U Bisei Lego Dataset.zip","wb") as f:
      request = requests.get(source)
      print(f"[INFO] Unzipping file from {source} into {data_path / dataset_folder}")
      f.write(request.content)
    with zipfile.ZipFile(data_path / file_name) as zip_ref:
      print(f"[INFO] Extracting to {data_path}")
      zip_ref.extractall(data_path)

    if remove_source:
      os.remove(data_path / file_name)

def walk_through_dir(data_path):
  """Explore the data path, listing the dirpaths, dirnames, filenames
  Args:
    data_path (str or os.PathLike): path to data
  """
  for dir_path,dirnames,filenames in os.walk(data_path):
    print(f"There are {len(dirnames)} directories and {len(filenames)} files in {dir_path}")



