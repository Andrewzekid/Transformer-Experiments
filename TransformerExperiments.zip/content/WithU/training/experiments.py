"""
Functions for keeping track of and making experiments
"""
import random
import torch
import torch.nn as nn
from tqdm.auto import tqdm
from torch.utils.tensorboard import SummaryWriter
import pathlib

from typing import List,Tuple,Dict
import warnings
import torchvision
import torchmetrics
from pathlib import Path
import matplotlib.pyplot as plt
import cv2
from torch.utils.data import IterableDataset
from torch.utils.data import DataLoader
import torchvision
from WithU.training import train
import os
from torchvision import datasets
from torchvision.transforms import v2
from torchvision.datasets.folder import make_dataset
import itertools
warnings.filterwarnings('ignore')

import torch.nn as nn
device = 'cuda' if torch.cuda.is_available() else "cpu" # or 'cpu'






class VideoDataset(IterableDataset):
  """Custom dataset for loading in videos"""
  def __init__(self,target_directory:str,epoch_size=None,frames_per_sample=32,stride=2,transform=None):
    """Initializes a VideoDataset object
    Args:
    target_directory (str): path to directory where unzipped dataset belongs to
    epoch_size (int): number of videos to sample per batch
    frames_per_sample(int): number of frames to sample per video
    stride(int): how many frames to skip. e.g: if stride =2, means sample one frame every other frame
    transform (torchvision.transforms.Compose): transforms object to transform the data with
    """
    self.stride = stride
    self.target_directory = target_directory
    self.clip_len = frames_per_sample
    # print(target_directory)
    self.paths = list(pathlib.Path(target_directory).glob("*/*.mp4")) #expects With U Bisei Lego Dataset/class_name/abc.mp4
    # print(self.paths)
    if epoch_size is None:
      # print("No epoch size found, setting size to self.paths")
      self.epoch_size = len(self.paths)
    else:
      self.epoch_size = epoch_size
    self.transform = transform
    self.classes,self.class_to_idx = self.find_classes()
    self.samples = make_dataset(self.target_directory,self.class_to_idx,extensions=[".mp4"])
    # print(self.samples)


  def load_video(self,index:int):
    """Load in a video from an index. Returns a tensor [T,H,W,C] corresponding to video frames"""
    video_path = self.paths[index]
    vframes = torchvision.io.read_video(video_path)[0]
    # print(f"Shape of loaded in video: {vframes.shape}")
    return vframes

  def get_random_n_indicies(self,total_frames,n:int=32,stride:int=2) -> Tuple[int,int]:
    """Given the total frames in a video and the number of frames per sample, returns a list of n number of frames from a sample"""
    #calculate start point:
    #start = 0 to (total - 32)
    latest_start = total_frames - (self.clip_len*stride)
    start_idx = random.randint(0,latest_start)
    return list(range(start_idx,start_idx + (self.clip_len*stride+1))) #e.g: for 5 frames, 0 1 2 3 4 and n=2, latest is 5 - 2 = 3. 3 + 2 = 5 OOB but 3 + 1 = 4.

  def __iter__(self):
      # print("Starting iteration")

      for _ in range(self.epoch_size):
          # Get random sample
          # print(f"Current samples are: {self.samples}")
          path, target = random.choice(self.samples)
          # print(f"Processing video: {path}")

          # Get video object
          # print("Reading video...")
          vid = torchvision.io.VideoReader(path, "video")
          metadata = vid.get_metadata()
          video_frames = []  # video frame buffer
          # print("Video metadata:")

          # Calculate the maximum starting frame
          total_frames = int(metadata["video"]['duration'][0] * metadata["video"]['fps'][0])
          max_start_frame = max(0, total_frames - (self.clip_len * self.stride))

          # Randomly select a starting frame
          start_frame = random.randint(0, max_start_frame)
          start_time = start_frame / metadata["video"]['fps'][0]
          # print(f"Starting from frame {start_frame} (time: {start_time:.2f}s)")

          for frame in itertools.islice(vid.seek(start_time), 0, self.clip_len * self.stride, self.stride):
              # Apply transforms
              transformed = self.transform(frame['data'].float())
              transformed /= 255.0
              video_frames.append(transformed.permute(1,2,0))
              current_pts = frame['pts']

          # Stack it into a tensor
          video = torch.stack(video_frames, 0)

          # print(f"Video tensor shape: {video.shape}")

          output = (video,target)
              # 'path': path,
              # 'video': video,
              # 'target': target,
              # 'start': start_time,
              # 'end': current_pts
          # }
          yield output

  def __len__(self):
    return len(self.samples)

  def find_classes(self) -> Tuple[List,Dict]:
    """Finds the class folder names in target directory"""
    classes = sorted(entry.name for entry in os.scandir(self.target_directory) if entry.is_dir())
    if not classes:
      #raise error
      raise FileNotFoundError(f"No classes found in {self.target_directory}!")

    class_to_idx = {class_name:i for i,class_name in enumerate(classes)}
    return classes,class_to_idx #1,2


def create_writer(experiment_name:str,
                  model_name: str,
                  extra: str = None):
  """Creates a torch.utils.tensorboard.writer.SummaryWriter() instance tracking to a specific folder"""
  from datetime import datetime
  import os

  #Get timestamp of current date in reverse order
  timestamp = datetime.now().strftime("%Y-%m-%d")

  if extra:
    #Create log directory path
    log_dir = os.path.join("runs",timestamp,experiment_name,model_name,extra)
  else:
    log_dir = os.path.join("runs",timestamp,experiment_name,model_name)
  print(f"[INFO] Created SummaryWriter saving to {log_dir}")
  return SummaryWriter(log_dir=log_dir)

def prepare_model(model:torch.nn.Module,hidden_units:int=768,classes:int=3,device=device) -> torch.nn.Module:
  """Freeze the base layers and prepare for fine tuning
  Args:
    model(torch.nn.Module): model to have its base layers frozen
    classes (int): number of classes
    hidden_units (int): number of hidden units on original layer
  Returns:
    model with base layers frozen and classifier head changed
  """
  #freeze base params
  for param in model.parameters():
    param.requires_grad = False

  #change classifier head
  model.classifier = nn.Sequential(
      nn.Linear(in_features=hidden_units,out_features=classes)
  ).to(device)

  return model

def create_experiments(epochs:List[int],
                       target_directory: str,
                       batch_sizes: List[int],
                       models: List[torch.nn.Module],
                       frames_per_video: List[int],
                       strides: int,
                       learning_rates: List[float],
                       hidden_sizes: List[int],
                       loss_functions: List[torch.nn.Module],
                       data_pipelines,
                       transform: torchvision.transforms.Compose = None,
                       num_classes:int=3,
                       strategy:str = "one-by-one",
                       device=device) -> Dict[str,Dict[List,int]]:
  """Tracks different experiments and returns their results
  Args:
    data_pipelines: pipeline functions needed to preprocess videos before training
    epochs (List): list of integers for the different number of epochs to traing for
    target_directory (str or os.PathLike): path to directory of dataset
    batch_sizes(List): list of integers for the different batch_sizes to use
    models (List): list of different models to use
    learning_rates (List): list of different learning rates to use
    frames_per_video (List): a list containing how many frames to sample per video for each model
    stride (int): rate of sampling. stride of 2 = sample one frame every 2 frames.
    transform: data transform
    hidden_sizes (List): number of hidden units on classifier layer corresponding to each model
    device: device to train on
    strategy (str): "one-by-one" or "all" -> how to load and predict on each video. if "one-by-one", each video is passed through the data pipeline and predictions are made one video at a time and the final predictions stacked into a tensor
    if "all", then the whole batch is predicted on at once.
    loss_functions (List of torch.nn.Module): list of loss functions, one for each model
    num_classes(int): number of classes
  Returns:
  Dictionary of model names as keys and dictionary of their key metrics as values
  {"model_1": {"train_loss":[....],"train_acc":[...],...},"model_2":{"train_loss":[...]}}
  """

  torchvision.set_video_backend("pyav")
  results = dict()
  accuracy = train.accuracy
  f1 = torchmetrics.F1Score(task="multiclass", num_classes=num_classes,average="macro").to(device) #>>> f1(preds, target)
  experiment_number = 0

  for i in range(len(models)):
    model = models[i]
    hidden_size = hidden_sizes[i]
    # #Prepare model for fine tuning
    # model = prepare_model(model,hidden_size,num_classes,device)
    try:
     model_name = model.name
    except:
      model_name = model.base_model_prefix

    #Get data pipeline used in training
    data_pipeline = data_pipelines[i]
    experiment_name = ""
    #Get loss function
    loss_fn = loss_functions[i]

    #Get video sampling parameters
    stride = strides[i]
    frames_per_sample = frames_per_video[i]

    for batch_size in batch_sizes:
      dataset = VideoDataset(target_directory=target_directory, stride=stride, frames_per_sample=frames_per_sample, epoch_size=batch_size, transform=transform)
      loader = DataLoader(dataset,batch_size=batch_size)

      for learning_rate in learning_rates:

        optimizer = torch.optim.SGD(params=model.parameters(),lr=learning_rate)

        for num_epochs in epochs:
          experiment_number += 1
          print(f"[INFO] Experiment number: {experiment_number}")
          print(f"[INFO] Model: {model_name}")
          print(f"[INFO] Batch size: {batch_size}")
          print(f"[INFO] Number of epochs: {num_epochs}")
          print(f"[INFO] Learning Rate: {learning_rate}")
          writer = create_writer(experiment_name=f"{num_epochs}_epochs_batchsize_{batch_size}_learningrate_{learning_rate}",model_name=model_name)

          results[f"{model_name}/[{num_epochs},{batch_size},{learning_rate}]"] = train.train(model=model,
                    optimizer=optimizer,
                    train_dataset=dataset,
                    test_dataset=dataset,
                    loss_fn=loss_fn,
                    accuracy_fn=accuracy,
                    epochs=num_epochs,
                    f1=f1,
                    device=device,
                    writer=writer,
                    data_pipeline = data_pipeline,
                    batch_size=batch_size)
  return results
