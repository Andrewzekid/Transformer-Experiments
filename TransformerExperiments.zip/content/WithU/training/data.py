"""
File containing functions for data loading and processing

"""
import random
import os
from pathlib import Path
import matplotlib.pyplot as plt
import cv2
from torch.utils.data import IterableDataset
import torchvision
from torchvision import datasets
from torchvision.transforms import v2
from torchvision.datasets.folder import make_dataset

import pathlib
import torch
import itertools

def visualize_random_video_frames(dataset_path, n=3, frames_per_video=3, seed=42):
  """Visualize a certain number of frames from n videos taken from a dataset path
  Args:
    dataset_path (str or os.PathLike): path to unzipped dataset files
    n (int): number of videos to take from
    frames_per_video (int): number of frames per video to visualize
    seed (int): random seed
  Sample use:
  visualize_random_video_frames(dataset_path, n=3, frames_per_video=3, seed=42)
  """
    # Get video paths
  video_paths = list(Path(dataset_path).glob("*/*.mp4"))  # Assuming .mp4 format, adjust if needed
  print(f"Found {len(video_paths)} videos")

  if seed:
      random.seed(seed)

  chosen_video_paths = random.sample(video_paths, k=min(n, len(video_paths)))

  for video_path in chosen_video_paths:
      # Open the video file
      cap = cv2.VideoCapture(str(video_path))

      # Get video properties
      frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

      # Randomly select frames
      frame_indices = random.sample(range(frame_count), k=min(frames_per_video, frame_count))

      # Create a matplotlib figure with subplots
      fig, axes = plt.subplots(1, frames_per_video, figsize=(15, 5))
      fig.suptitle(f"Video: {video_path.stem}")

      for i, frame_index in enumerate(frame_indices):
          # Set the frame position
          cap.set(cv2.CAP_PROP_POS_FRAMES, frame_index)

          # Read the frame
          ret, frame = cap.read()

          if ret:
              # Convert BGR to RGB
              frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

              # Display the frame
              axes[i].imshow(frame_rgb)
              axes[i].set_title(f"Frame {frame_index}")
              axes[i].axis('off')
          else:
              print(f"Could not read frame {frame_index} from {video_path}")

      # Release the video capture object
      cap.release()

      plt.tight_layout()
      plt.show()

from typing import Tuple, List,Dict
def find_classes(target_directory: str) -> Tuple[List,Dict]:
    """Finds the class folder names in target directory
    Args:
      target_directory(str): path to unzipped dataset directory

    Returns:
      tuple of (classes,class_to_idx)
      classes: ["action 1","action 2",....]
      class_to_idx: {"action 1":0, "action 2":1,...}

    Sample Usage:
    classes, class_to_idx = find_classes(dataset_path)
    print(classes,class_to_idx)
    """
    import os
    classes = sorted(entry.name for entry in os.scandir(target_directory) if entry.is_dir())
    if not classes:
      #Raise error
      raise FileNotFoundError(f"No classes found in {target_directory}!")
    class_to_idx = {class_name:i for i,class_name in enumerate(classes)}
    return classes,class_to_idx #1,2


